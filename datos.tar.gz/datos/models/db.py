# -*- coding: utf-8 -*-

db = DAL('sqlite://productos.db');

db.define_table('producto',Field('codigo'),
                        Field('nombre'),
                        Field('categoria'),
                        Field('stock','integer'),
                        Field('descripcion','text'))
                        
db.producto.codigo.requires = IS_NOT_EMPTY(error_message='No puede estar vacio')
db.producto.nombre.requires = IS_LENGTH(20,error_message='No mas de 20')
db.producto.categoria.requires = IS_ALPHANUMERIC()
db.producto.stock.requires =IS_NOT_EMPTY()
db.producto.descripcion.default = 'edite descripción '

db.define_table('almacen',Field('codigo'),
                        Field('nombre_almacen'),
                        Field('tipo'),
                        Field('numero_almacen','integer'))

db.almacen.codigo.requires = IS_NOT_EMPTY()
db.almacen.codigo.requires = IS_ALPHANUMERIC()
db.almacen.nombre_almacen.requires = IS_LENGTH(100)
db.almacen.nombre_almacen.requires = IS_NOT_EMPTY()
db.almacen.numero_almacen.requires = IS_INT_IN_RANGE(0,10)
