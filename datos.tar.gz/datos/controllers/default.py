# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a samples controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
## - call exposes all registered services (none by default)
#########################################################################

def index():
    productos = db().select(db.producto.ALL)
    return dict(producto=productos)

def detalle():
    producto = db(db.producto.codigo==request.args(0)).select()
    return dict(producto=producto)
